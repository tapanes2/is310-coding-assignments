# TikTok Virality Maze – Alex

Navigate from `enter` → `fy_page` → `audio` → `trend` → `exit`

## Start Here
```bash
cd enter
ls
cat README.txt

.\hide-dotfiles.ps1

ls -la
cd folder_name
cat clue.txt

