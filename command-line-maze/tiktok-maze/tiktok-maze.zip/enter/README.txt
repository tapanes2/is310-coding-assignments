Enter the TikTok Mazer here. Your first step is to read clue1.text.
