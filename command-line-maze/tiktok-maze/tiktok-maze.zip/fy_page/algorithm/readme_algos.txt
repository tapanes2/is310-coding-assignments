Inside algorithms, one file tells you what to do next.
